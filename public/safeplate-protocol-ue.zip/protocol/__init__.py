"""Official SafePlate protocol engine."""
